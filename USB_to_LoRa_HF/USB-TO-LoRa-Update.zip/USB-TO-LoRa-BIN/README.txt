EN:
The latest firmware version number is currently V1.2. 
To update the firmware, please confirm the corresponding product model:

USB-TO-LoRa-HF-B uses ordinary crystal oscillator(XTAL), frequency band is 850~930MHz
USB-TO-LoRa-HF uses temperature compensated crystal oscillator (TCXO), frequency band is 850~930MHz
USB-TO-LoRa-LF-B uses ordinary crystal oscillator(XTAL), frequency band is 410~490MHz
USB-TO-LoRa-LF-B uses temperature compensated crystal oscillator (TCXO), frequency band is 410~490MHz

please refer to Wiki for update 

changelog
V1.2, Added the function of restoring factory settings by long pressing the KEY button, and fixed the serial port suspended animation problem.
V1.1, fix bug of losing AT parameters when power off
V1.0, first version

CN:
目前最新固件版本号为 V1.2, 更新固件请确认对应产品型号:
USB-TO-LoRa-HF-B 型号使用普通晶振, 频段为 850~930MHz
USB-TO-LoRa-HF 型号使用温补晶振(TCXO), 频段为 850~930MHz
USB-TO-LoRa-LF-B 型号使用普通晶振, 频段为 410~490MHz
USB-TO-LoRa-LF-B 型号使用温补晶振(TCXO), 频段为 410~490MHz
参考升级固件章节升级对应型号固件

changelog
V1.2 增加 KEY 按键长按恢复出厂设置功能, 修复串口假死问题
V1.1 修复掉电保存
V1.0 初始固件

